//$(document).ready(function() {
//	
//	var gotoSource=document.getElementById("gotoSource");
//	
//	//var new_data= $("#1").data("href");
//	gotoSource.innerHTML="pppp";
//	var s=document.getElementById("sfl").value; 
//	alert(s);
//
//});
