$(document).ready(function() {
	
$('#button_design').click(function() {
	
	$("#dvLoading").fadeIn();
});
});

function hello(){
	
	var buton = document.getElementById("dvLoading");
	buton.innerHTML="<img src='../images/Logo3.png'>";
	//<img src='../images/loading.gif'>
}