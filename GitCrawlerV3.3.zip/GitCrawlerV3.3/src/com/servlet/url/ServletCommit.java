package com.servlet.url;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.logic.business.CommentCutter;
import com.logic.business.CommitData;
import com.logic.business.CommitOptimiser;

/**
 * Servlet implementation class ServletCommi
 */
@WebServlet("/ServletCommit")
public class ServletCommit extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public ServletCommit() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		ArrayList<String> commitCode=new ArrayList<String>();
		
		String info = request.getParameter("message");
		
		CommitData commit = new CommitData();
		//System.out.println("zzzzzzzzzzzzzzzzzzzzzzzz");
		String commitData = commit.getCommitInfo(info);
		CommitOptimiser optimiser = new CommitOptimiser(commitData,info); 
		//commitCode=optimiser.onlyCode;
		
		for(int i=0;i<commitCode.size();i++)
		{
			//System.out.println(commitCode.get(i).toString());
			//System.out.println("zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz");
		}
		CommentCutter cutter = new CommentCutter(commitData);
		commitData = cutter.HTMLtagRemover(commitData);
		PrintWriter print = response.getWriter();
		print.println(commitData);
		
		//System.out.println(commitData);
	}
}
