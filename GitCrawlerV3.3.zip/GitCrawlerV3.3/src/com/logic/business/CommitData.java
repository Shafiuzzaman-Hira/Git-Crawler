package com.logic.business;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;

public class CommitData {
	
	private String name = System.getProperty("user.name");
	
	private String execute(String command) {
		StringBuilder sb = new StringBuilder();
		String[] commands = new String[] { "/bin/sh", "-c", command };
		try {
			Process proc = new ProcessBuilder(commands).start();
			BufferedReader stdInput = new BufferedReader(new InputStreamReader(
					proc.getInputStream()));
 
			BufferedReader stdError = new BufferedReader(new InputStreamReader(
					proc.getErrorStream()));
 
			String s = null;
			while ((s = stdInput.readLine()) != null) {
				sb.append(s);
				sb.append("\n");
			}
 
			while ((s = stdError.readLine()) != null) {
				sb.append(s);
				sb.append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return sb.toString();
	}

	public String getCommitInfo(String info) {
		// TODO Auto-generated method stub
		
			// TODO Auto-generated method stub
			File file = new File("/opt/lampp/htdocs/xampp/Projects");
			 
			String files[] = file.list();
			    
				File fileSearch = new File(file, files[0]);
				System.out.println(fileSearch);
				return execute("cd "+fileSearch+" && git show "+info);//| head -3"
				
				
				//return datas;
			    
		
		
		
	}

}
