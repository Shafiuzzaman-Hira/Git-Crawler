package com.logic.business;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;

import com.sun.xml.internal.bind.v2.runtime.unmarshaller.XsiNilLoader.Array;

public class CommitOptimiser
{
	String commitResult;
	String info;
	String[] spiltDiff ;
	public ArrayList<String> onlyCode=new ArrayList<String>();
	
	public CommitOptimiser(String commitResult,String info) 
	{
		this.commitResult = commitResult;
		this.info = info;
		createOnlyCodeList();
		
	}
	
	
	public ArrayList<String> createOnlyCodeList()
	{
		File file = new File("/opt/lampp/htdocs/xampp/Projects");
		//File fileWrite = new File("/opt/lampp/htdocs/xampp/write.txt");
		String files[] = file.list();
		    
		File fileSearch = new File(file, files[0]);
		System.out.println(fileSearch);
	    String data = execute("cd "+fileSearch+" && git show "+info+" | sed '/^+/!d;'");
		//System.out.println("success");
	    //System.out.println(data);
	    String[] out = data.split("\\+\\+\\+");
	    for(int i=0;i<out.length;i++)
	    {
	    	System.out.println(out[i]);
	    }
	    //onlyCode = (ArrayList<String>) Arrays.asList(out);
	   // System.out.println();
		return onlyCode;
	}
	
	private String execute(String command) {
		StringBuilder sb = new StringBuilder();
		String[] commands = new String[] { "/bin/sh", "-c", command };
		try {
			Process proc = new ProcessBuilder(commands).start();
			BufferedReader stdInput = new BufferedReader(new InputStreamReader(
					proc.getInputStream()));
 
			BufferedReader stdError = new BufferedReader(new InputStreamReader(
					proc.getErrorStream()));
 
			String s = null;
			while ((s = stdInput.readLine()) != null) {
				sb.append(s);
				sb.append("\n");
			}
 
			while ((s = stdError.readLine()) != null) {
				sb.append(s);
				sb.append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return sb.toString();
	}
	
	
}
