package com.logic.business;

public class CommentCutter {
	
	String codeString,finalString;
	
	public CommentCutter(String codeString)
	{
		this.codeString = codeString;
	}
	
	public CommentCutter()
	{
		
	}
	
	public String getFinalResultString()
	{
		String commentLsssString= codeString.replaceAll("//.*|(\"(?:\\\\[^\"]|\\\\\"|.)*?\")|(?s)/\\*.*?\\*/","");
		//System.out.println(finalString);
		//finalString= commentLsssString.replaceAll("<("[^"]*"|'[^']*'|[^'">])*>", "");
		HTMLtagRemover(commentLsssString);
		return finalString;
	}

	public String HTMLtagRemover(String commentLsssString) {
		finalString= commentLsssString.replaceAll("<", "&lt;");
		finalString= finalString.replaceAll(">", "&gt;");
		return finalString;
	}
}
