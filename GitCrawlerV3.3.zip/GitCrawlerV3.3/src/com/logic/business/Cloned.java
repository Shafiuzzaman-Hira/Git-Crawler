package com.logic.business;

import java.awt.Checkbox;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;

public class Cloned {
	boolean flag = false;
	public boolean getFile()
	{
		File file = new File("/opt/lampp/htdocs/xampp/Projects");
		try {
			Check(file);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
		
	}
	
	private void Check(File file) throws IOException {
		 
		if (file.isDirectory()) {
 
			// directory is empty, then delete it
			if (file.list().length == 0) {
 
				flag = false;
 
			} else {
				flag = true;
				
			}
			
		}
	}
}




