package com.logic.business;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
 
public class Test{
	   static int i;
	   private String name = System.getProperty("user.name");
		public Test(String url){
			check(url);
		}

	public void delete(File file) throws IOException {
 
		if (file.isDirectory()) {
 
			
			if (file.list().length == 0) {
 
				file.delete();
				System.out.println("Directory is deleted : "
						+ file.getAbsolutePath());
 
			} else {
 
				// list all the directory contents
				String files[] = file.list();
 
				for (String temp : files) {
					// construct the file structure
					File fileDelete = new File(file, temp);
 
					// recursive delete
					delete(fileDelete);
				}
 
				// check the directory again, if empty then delete it
				if (file.list().length == 0) {
					file.delete();
					System.out.println("Directory is deleted : "
						 	+ file.getAbsolutePath());
				}
			}
 
		} else {
			// if file, then delete it
			file.delete();
			System.out.println("File is deleted : " + file.getAbsolutePath());
		}
	}
 
	public String execute(String command) {
		StringBuilder sb = new StringBuilder();
		String[] commands = new String[] { "/bin/sh", "-c", command };
		try {
			Process proc = new ProcessBuilder(commands).start();
			BufferedReader stdInput = new BufferedReader(new InputStreamReader(
					proc.getInputStream()));
 
			BufferedReader stdError = new BufferedReader(new InputStreamReader(
					proc.getErrorStream()));
 
			String s = null;
			while ((s = stdInput.readLine()) != null) {
				sb.append(s);
				sb.append("\n");
			}
 
			while ((s = stdError.readLine()) != null) {
				sb.append(s);
				sb.append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return sb.toString();
	}
	
	private void check(String url)
	{
		long time = System.currentTimeMillis();
	
		//File folder = new File("/home/"+name+"/Documents/GitCrawler"); //cd /opt/lampp/htdocs
		File folder = new File("/opt/lampp/htdocs/xampp/");
		folder.mkdir();
	
		File file = new File("/opt/lampp/htdocs/xampp/Projects");//Pro
		try {
			delete(file);
		} catch (IOException e) {
			e.printStackTrace();
		}
 
		file.mkdir();
		System.out.println(file.getPath());
		
 
		String result = execute("cd "+file+"; "+url);
		System.out.println(result);
		System.out.println(result.length());
		if(result.contains("fatal"))
		{
			System.out.println("fatal error");
		}
		System.out.println("Time taken to execute commands: "
				+ (System.currentTimeMillis() - time) + " mili seconds");
        i++;
		System.out.println(i);
	}
}