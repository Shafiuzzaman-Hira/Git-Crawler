/*package com.logic.business;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class TestforSearch {
	
	private static String userName = System.getProperty("user.name");
	private static String info;
	static ArrayList<String> paths = new ArrayList<String>();
	static ArrayList<String> results =  new ArrayList<String>();
	public static void main(String[] args) {
	
		getResultData();
	
	}
	private static void read(File file) throws IOException {
		
		if (file.isDirectory()) {

			// directory is empty, then delete it
			if (file.list().length == 0) {

			} else {

				String files[] = file.list();
				File fileRead = null;

				// construct the file structure
				for (int i = 0; i < files.length; i++) {
					String temp = files[i];

					fileRead = new File(file, temp);

					// System.out.println("fileRead: "+fileRead);

					if (fileRead.isDirectory()) {
						String result = execute("cd " + fileRead);
						System.out.println("cd to :" + result);
					}

					read(fileRead);

				}

			}

		} else {
			// System.out.println("qq: "+file.getName());
			// c,cs,cpp,html,htm,css,js,jsp,java,php
			if (file.getName().toString().contains(".java")
					|| file.getName().toString().contains(".html")
					|| file.getName().toString().contains(".css")
					|| file.getName().toString().contains(".jsp")) {
				System.out.println("qq2: " + file.getPath());
				String result = execute("cat " + file + " | grep " + info);
				if (!(result.equals(""))) {
					
					results.add(result);
					paths.add(file.getPath());

				}
			}

		}
	}

	private static String execute(String command) {
		StringBuilder sb = new StringBuilder();
		String[] commands = new String[] { "/bin/sh", "-c", command };
		try {
			Process proc = new ProcessBuilder(commands).start();
			BufferedReader stdInput = new BufferedReader(new InputStreamReader(
					proc.getInputStream()));

			BufferedReader stdError = new BufferedReader(new InputStreamReader(
					proc.getErrorStream()));

			String s = null;
			while ((s = stdInput.readLine()) != null) {
				sb.append(s);
				sb.append("\n");
			}

			while ((s = stdError.readLine()) != null) {
				sb.append(s);
				sb.append("\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return sb.toString();
	}

	private static void getResultData() {
		Map<String, String> searchRe = new HashMap<String, String>();
		long time = System.currentTimeMillis();
		File file = new File("/home/" + userName + "/Documents/GitCrawler/");

		String result = execute("cd /home/" + userName
				+ "/Documents/GitCrawler/Projects");
		System.out.println(result);
		try {
			read(file);
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Time taken to execute commands: "
				+ (System.currentTimeMillis() - time) + " mili seconds");
		
	}
}*/