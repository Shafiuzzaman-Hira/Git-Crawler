package com.info.all;

public class ResultInfo {
	 String paths;
	 String results;
	 
	 
	public String getPaths() {
		return paths;
	}
	public void setPaths(String paths) {
		this.paths = paths;
	}
	public String getResults() {
		return results;
	}
	public void setResults(String results) {
		this.results = results;
	}
	 
	 

}
